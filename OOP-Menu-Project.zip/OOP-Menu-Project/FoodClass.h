#ifndef FOOD_H
#define FOOD_H
#include <iostream>
#include <string>
#include <iomanip>
#include "MenuClass.h"
#include "BeverageClass.h"
#include <fstream>
#include <limits>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <limits>
using namespace std;

Color::Modifier red(Color::FG_RED);
Color::Modifier def(Color::FG_DEFAULT);
Color::Modifier grey(Color::BG_LGREY);
Color::Modifier magenta(Color::FG_MAGENT);
Color::Modifier backdef(Color::BG_DEFAULT);

class Food: public Menu
{
    public:
    void Item()
    {

    }
    std::string getNameFromUser()
    {
        std::cout << magenta << "enter name: ";
        std::string name{};
        std::cin >> name;
        return name;
    }
    int getPriceFromUser()
    {
        std::cout << magenta << "enter price: ";
        float price{};
        std::cin >> price;
        return price;
    }
    std::string getTempFromUser()
    {
        std::cout << magenta << "Is this served hot? (enter 1 to confirm, any other key to deny): ";
        std::string chilled_temp;
        std::string temp{};
        std::cin >> chilled_temp;
        if(chilled_temp == "1")
        {
            temp = "Yes";
        } else
        {
            temp = "No";
        }
    return temp;
    }
    std::string getOptionFromUser()
    {
        std::cout << magenta << "Is this vegetarian? (press 1 to confirm): ";
        std::string option{};
        std::string alcoholic_option;
        std::cin >> alcoholic_option;
        if(alcoholic_option == "1")
        {
            option = "Vegetarian";
        } else
        {
            option = "Non-vegetarian";
        }
        return option;
    }
    int getCalorieFromUser()
    {
        std::cout << magenta << "enter calories: ";
        int calorie{};
        std::cin >> calorie;
        return calorie;
    }
//---------------------------------------------------------------------------------------------------


    int AddFood()
    {
        std::cout << "Foods: " << "\n";
        Food new_food;

        std::string name = new_food.getNameFromUser();
        int price = new_food.getPriceFromUser();
        std::string temp = new_food.getTempFromUser();
        std::string option = new_food.getOptionFromUser();
        int calorie = new_food.getCalorieFromUser();
        new_food.Item();

        ofstream MenuFile("FoodMenu.txt", ofstream::app);

        MenuFile << std::left << std::setw(17) << name << std::left << std::setw(10) << price << std::left << std::setw(12) << temp
        << std::left << setw(20) << option << std::left << std::setw(20) << calorie << endl;

        MenuFile.close();

        std::string menuText;
        ifstream MenuReadFile("FoodMenu.txt");

        static int counter = 0;

        std::cout << red << std::left << std::setw(17) << "Food Option" << std::left << std::setw(10) << "Price ($)" << std::left
        << std::setw(12) << "Served Hot" << std::left << std::setw(20) << "Vegetarian" << std::left << std::setw(20) << "Calories (kCal)" << endl;
        std::cout << def << "===============================================================================" << endl;
        while(getline (MenuReadFile, menuText))
            {
            std::cout << red <<  menuText << endl;
            std::cout << def << "-------------------------------------------------------------------------------" << endl;
            }
        MenuReadFile.close();
        //std::cout << counter << endl;
        counter++;
        return price;
    }

    int SeeFoodMenu()
    {
        std::string menuText;
        ifstream MenuReadFile("FoodMenu.txt");

        static int food_count = 0;

        std::cout << grey << red << std::left << std::setw(17) << " Food Option" << std::left << std::setw(10) << "Price($)" << std::left
        << std::setw(12) << "Served Hot" << std::left << std::setw(20) << "  Vegetarian" << std::left << std::setw(20) << "Calories(kCal)         " << endl;
        std::cout << grey << def << "===============================================================================   " << endl;
        while(getline (MenuReadFile, menuText))
            {
                food_count++;
                std::cout << grey << red << food_count << ": ";
                std::cout << grey << red <<  menuText << endl;
                std::cout << grey << def << "-------------------------------------------------------------------------------   " << backdef << endl;
            }
        MenuReadFile.close();

        return 0;
    }

    int FoodOrder()
    {
        fstream file("FoodMenu.txt");
        int item_number;
        cout << "Enter item number: ";
        cin >> item_number;

        GotoLine(file, item_number);

        string name, temp, option, calorie;
        int price;
        file >> name >> price >> temp >> option >> calorie;

        ofstream ReceiptFoodFile("MenuReceipt.txt", ofstream::app);
        ReceiptFoodFile << price << " " << name << " " << temp << " " << option << " " << calorie << endl;

        return 0;
    }

};

#endif