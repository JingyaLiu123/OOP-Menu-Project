#include "MenuClass.h"
#include "BeverageClass.h"
#include "FoodClass.h"
#include <string>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <fstream>
#include <vector>
#include <sstream>
#include <limits>

using namespace std;

int main()
{
//------------Colours----------------------------------------------------------------------------------------------

    Color::Modifier red(Color::FG_RED); //defining kewords for outputting to terminal
    Color::Modifier green(Color::FG_GREEN); //in colours such as red, green, blue, and white
    Color::Modifier blue(Color::FG_BLUE);
    Color::Modifier white(Color::FG_DEFAULT);
//------------Menu Program ----------------------------------------------------------------------------------------

    std::cout <<"~ Welcome to Menu Program! ~"<< "\n"; //entering the Menu program
    while(true) // loops program back to starting menu when a function is finished
    { //listing the 5 Menu Program abilities
        std::cout << "I would like to: " << "\n" << "Add to Beverage Menu --> press 1"
        << "\n" << "See Beverage Menu --> press 2" << "\n"
        << "Add to Food Menu --> press 3" << "\n" << "See Food Menu --> press 4" << "\n" << "Make Order --> press 5"
        << "\n" << "control 'c' to exit program" << endl; //stop the loop and finish the program by 'control-c'

        int menu_select; //initialising an integer variable and taking user input
        std::cin >> menu_select;

        Beverage new_beverage; //creates an object in Beverage class
        Food new_food; // creates an object in Food Class

        switch (menu_select) //switch loop to run selected program function
        {
            //----------Adding to Beverages Menu------------------------------------------------------------------
            case 1:
                new_beverage.AddBev(); //calls function to write to BeverageMenu.txt
                break; //breaks from switch loop and allows user to select program function again
            //---------Printing out Beverages Menu----------------------------------------------------------------
            case 2:
                new_beverage.SeeBevMenu(); //calls function to print out beverages menu
                break;
            //---------Adding to Food Menu------------------------------------------------------------------------
            case 3:
                new_food.AddFood(); //calls function to write to FoodMenu.txt
                break;
            //---------Printing out Food Menu---------------------------------------------------------------------
            case 4:
                new_food.SeeFoodMenu(); //calls function to print out foods menu
                break;
            //---------Making order for Beverage and/or Food------------------------------------------------------
            case 5: //calls functions in Beverage and Food classes to print out receipt
                //-------------setting customer and receipt information-------------------------------------------
                std::string cust_name; // initialising a string variable and taking user input for their name
                std::cout << "Enter customer name: ";
                std::cin >> cust_name;
                time_t timetoday; //determining current time in UTC
                time(&timetoday);
                std::string Date_time = asctime(localtime(&timetoday)); //initialising 'Date_time' string variable

                //-------------Entering loops for making order----------------------------------------------------
                while(true) // loops back to 'I want to order: ' selection menu once a switch loop case ends
                {
                    std::cout << "I want to order: " << "\n" << "food --> press 6" << "\n" << "beverage --> press 7"
                    << "\n" << "finish and print receipt --> press 8" << endl;
                    int order_choice;
                    std::cin >> order_choice;

                    switch (order_choice)
                    {
                        //------------Making order from Food Menu------------------------------------------------
                        case 6:
                        {
                            fstream file("FoodMenu.txt"); //reading in 'FoodMenu.txt'
                            new_food.FoodOrder(); //calling to FoodOrder() function in Food class
                            continue; //switch loop begins again
                        }
                        //-----------Making order from Beverages Menu--------------------------------------------
                        case 7:
                        {
                            fstream file("BeverageMenu.txt"); //reading in 'BeverageMenu.txt'
                            new_beverage.BevOrder(); //calling to BevOrder() function in Beverage class
                            continue; //switch loop begins again
                        }
                        case 8:
                        {
                            break; //exits switch loop to print out receipt
                        }
                    }
                        //----------Making and Printing out receipt----------------------------------------------
                            std::string MenuPrice; //initialising a string to use for reading in from txtfile
                            float total; // initialising float variable to sum prices of order items
                            ifstream MenuReceiptFile("PriceReceipt.txt"); //reading in 'PriceReceipt.txt'
                            while(getline(MenuReceiptFile, MenuPrice))    //line by line
                            {
                                float ItemMenuPrice = std::stof(MenuPrice);
                                total = total + ItemMenuPrice; //tally of the prices of ordered Food and Bev items
                            }
                            MenuReceiptFile.close(); //closing reading in from 'PriceReceipt.txt'
                        //---------Printing out header of receipt------------------------------------------------
                            std::cout << "=================================" << endl;
                            std::cout << "Thank You For Using Menu Program" << "\n" << "~~~~~~~~~~~~[ ^ U ^ ]~~~~~~~~~~~"
                            << "\n"; //printing out 'thank you' message and picture
                            std::cout << "=================================" << "\n" //printing partition
                            << "customer name: " << cust_name << "\n" //inserting user input for their name
                            << "UTC: " << Date_time << "\n" << "---------------------------------" << "\n"; //inserting date and time
                        //---------Printing info details of order-------------------------------------------------
                            cout << "Your Order was: ";
                            std::string receiptText; //initialising string to use for reading in 'MenuReceipt.txt'
                            ifstream receiptfile("MenuReceipt.txt"); //reading in 'MenuReceipt.txt' line by line
                            while(getline(receiptfile, receiptText))
                            {
                                std::cout << receiptText << ", "; //printing and separating info for order with ','
                            }
                            std::cout << endl;
                            string name, price, temp, option, calorie;
                            receiptfile >> name >> price >> temp >> option >> calorie;
                        //--------Printing out total cost for order-----------------------------------------------
                            std::cout << "---------------------------------" << "\n" << "Total: $" << std::setprecision(2)
                            << std::fixed << total << endl; //printing partition and tallied total price for order to 2 decimal places
                            std::cout << "=================================" << endl; //partition to end receipt
                            static int counter = 1;
                            cin.get();

                        remove("MenuReceipt.txt");
                        remove("PriceReceipt.txt");
                        break; //breaks from switch loop and back to while loop Making Order Selections
                }
                break; //breaks from while loop and back to Menu Program Selections
        }

    }
    return 0;
}

