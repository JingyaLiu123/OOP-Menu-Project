#ifndef FOOD_H
#define FOOD_H
#include <iostream>
#include <string>
#include <iomanip>
#include "MenuClass.h"
#include "BeverageClass.h"
#include <fstream>
#include <limits>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <limits>
using namespace std;

//----------------Colours-----------------------------------------------------------------------------------
Color::Modifier red(Color::FG_RED);
Color::Modifier def(Color::FG_DEFAULT);
Color::Modifier grey(Color::BG_LGREY);
Color::Modifier magenta(Color::FG_MAGENT);
Color::Modifier backdef(Color::BG_DEFAULT);

//----------------Food Child Class--------------------------------------------------------------------------
class Food: public Menu
{
    public:
    void Item(){} //virtual function

    std::string getNameFromUser() //function to take food name input from user
    {
        std::cout << magenta << "enter food name (no spaces): ";
        std::string name{};
        std::cin >> name;
        return name;
    }
    int getPriceFromUser() //function to take price input from user as float
    {
        std::cout << magenta << "enter food price: ";
        float price{};
        std::cin >> price;
        return price;
    }
    std::string getTempFromUser() //function to determine whether food is served hot
    {
        std::cout << magenta << "Is this served hot? (enter 1 to confirm, any other key to deny): ";
        std::string chilled_temp;
        std::string temp{};
        std::cin >> chilled_temp;
        if(chilled_temp == "1")
        {
            temp = "Yes";
        } else
        {
            temp = "No";
        }
    return temp;
    }
    std::string getOptionFromUser() //function to determine whether food is vegetarian
    {
        std::cout << magenta << "Is this vegetarian? (press 1 to confirm): ";
        std::string option{};
        std::string alcoholic_option;
        std::cin >> alcoholic_option;
        if(alcoholic_option == "1")
        {
            option = "Vegetarian";
        } else
        {
            option = "Non-vegetarian";
        }
        return option;
    }
    int getCalorieFromUser() //function to take input for calories in food item
    {
        std::cout << magenta << "enter calories: ";
        int calorie{};
        std::cin >> calorie;
        return calorie;
    }
    //-----------Methods used to execute main abilities listed in Menu Program selectio menu-----------------------------------
    //-------------Adding to Food menu-----------------------------------------------------------------------------------
    int AddFood()
    {
        std::cout << "Foods: " << "\n"; //entering AddFood() function
        Food new_food; //creating object in Food class
        std::string name = new_food.getNameFromUser(); //taking inputs from user
        int price = new_food.getPriceFromUser();
        std::string temp = new_food.getTempFromUser();
        std::string option = new_food.getOptionFromUser();
        int calorie = new_food.getCalorieFromUser();
        new_food.Item(); //call to virtual function

        //---------Writing to Food Menu txt file-----------------------------------------------------------------------
        ofstream MenuFile("FoodMenu.txt", ofstream::app); //writing to end of 'FoodMenu.txt'
        MenuFile << std::left << std::setw(17) << name << std::left << std::setw(10) << price << std::left << std::setw(12) << temp
        << std::left << setw(20) << option << std::left << std::setw(20) << calorie << endl; //outputting user inputs in table format
        MenuFile.close(); //closing writing to txt file

        //--------Reading from Food Menu txt file-------------------------------------------------------------------------------
        std::string menuText; //initialising string used to read in txt file line by line
        ifstream MenuReadFile("FoodMenu.txt"); //reading in from 'FoodMenu.txt'
        static int counter = 0; //counter for food item index
        //-------Printing out new Food menu table------------------------------------------------------------------------------
        std::cout << red << std::left << std::setw(17) << "Food Option" << std::left << std::setw(10) << "Price ($)" << std::left
        << std::setw(12) << "Served Hot" << std::left << std::setw(20) << "Vegetarian" << std::left << std::setw(20) << "Calories (kCal)" << endl;
        std::cout << def << "===============================================================================" << endl;
        while(getline (MenuReadFile, menuText)) //reading txt file line by line
            {
            std::cout << red <<  menuText << endl;
            std::cout << def << "-------------------------------------------------------------------------------" << endl;
            }
        MenuReadFile.close(); //closing reading in from 'FoodMenu.txt'
        counter++; //counter increments by 1 everytime new food is added
        return price;
    }

    //--------------Displaying Food Menu------------------------------------------------------------------------------------
    int SeeFoodMenu()
    {
        std::string menuText; //initialising string used to read in txt file line by line
        ifstream MenuReadFile("FoodMenu.txt"); //reading from 'FoodMenu.txt'
        static int food_count = 0; //counter for food item index
        //--------------printing out txt file in table format-----------------------------------------------------------------
        std::cout << grey << red << std::left << std::setw(17) << " Food Option" << std::left << std::setw(10) << "Price($)" << std::left
        << std::setw(12) << "Served Hot" << std::left << std::setw(20) << "  Vegetarian" << std::left << std::setw(20)
        << "Calories(kCal)         " << endl; //printing out contents of txt file in table format, and partition
        std::cout << grey << def << "===============================================================================   " << endl;
        while(getline (MenuReadFile, menuText))
            {
                food_count++; //food item index counter increments by 1 for every new line displayed
                std::cout << grey << red << food_count << ": ";
                std::cout << grey << red <<  menuText << endl;
                std::cout << grey << def << "-------------------------------------------------------------------------------   " << backdef << endl;
            }
        MenuReadFile.close(); //closing reading in from 'FoodMenu.txt'
        return 0;
    }
    //-------------Making order from Food Menu-------------------------------------------------------------------------------
    int FoodOrder()
    {
        fstream file("FoodMenu.txt"); //reading and writing to txt file
        int item_number; // taking in user input refering to food item index
        cout << "Enter item number: ";
        cin >> item_number;

        GotoLine(file, item_number); //reading in contents of 'FoodMenu.txt' as variables
        string name, temp, option, calorie; //initialising variables
        int price;
        file >> name >> price >> temp >> option >> calorie;

        ofstream ReceiptFoodFile("MenuReceipt.txt", ofstream::app); //creating and writing the name of order to txt file
        ReceiptFoodFile << name << endl;

        ofstream PriceFoodFile("PriceReceipt.txt", ofstream::app); //creating and writing price of order to txt file
        PriceFoodFile << price << endl;
        return 0;
    }
};
#endif