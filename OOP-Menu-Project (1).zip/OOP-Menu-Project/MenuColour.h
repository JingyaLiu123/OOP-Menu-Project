#include <ostream>
//---------Header file for displaying coloured outputs------------------------
namespace Color
{
    enum Code
    {
        FG_RED      = 31, //red words
        FG_GREEN    = 32, //green words
        FG_DEFAULT  = 39, //white words
        FG_MAGENT   = 35, //magenta/purple words
        BG_GREEN    = 42, //green background
        BG_LGREY    = 47, //light grey backgroun
        BG_DEFAULT  = 49 // default/blue background
    };
    class Modifier {
        Code code;
    public:
        Modifier(Code pCode) : code(pCode) {}
        friend std::ostream&
        operator<<(std::ostream& os, const Modifier& mod) {
            return os << "\033[" << mod.code << "m";
        }
    };
}