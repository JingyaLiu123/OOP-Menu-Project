#ifndef BEVERAGE_H
#define BEVERAGE_H
#include <iostream>
#include <string>
#include <iomanip>
#include "MenuClass.h"
#include "MenuColour.h"
#include <fstream>
#include <limits>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <limits>
using namespace std;

//-------------Colours----------------------------------------------------------------
    Color::Modifier green(Color::FG_GREEN);
    Color::Modifier blue(Color::FG_BLUE);
    Color::Modifier white(Color::FG_DEFAULT);
    Color::Modifier backgrey(Color::BG_LGREY);
    Color::Modifier backwhite(Color::BG_DEFAULT);

//-------------Defining GotoLine function--------------------------------------------
// locates specific line to read and write to text files line by line
    std::fstream& GotoLine(std::fstream& file, unsigned int num){
    file.seekg(std::ios::beg);
    for(int i=0; i < num - 1; ++i){
        file.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    }
    return file;
    }
//------------Beverages Child Class--------------------------------------------------
class Beverage: public Menu
{
    public:
    void Item(){} //virtual function

    std::string getNameFromUser() //function to take beverage name input from user
    {
        std::cout << "enter beverage name (no spaces): ";
        std::string name{};
        std::cin >> name;
        return name;
    }
    int getPriceFromUser() //function to take beverage price input from user as float
    {
        std::cout << "enter beverage price($): ";
        float price{};
        std::cin >> price;
        return price;
    }
    std::string getTempFromUser() //function to determine whether beverage is chilled
    {
        std::cout << "Is this beverage chilled? (enter 1 to confirm): ";
        std::string chilled_temp;
        std::string temp{};
        std::cin >> chilled_temp;
        if(chilled_temp == "1")
        {
            temp = "Yes"; //beverage chilled
        } else
        {
            temp = "No"; //beverage not chilled
        }
    return temp;
    }
    std::string getOptionFromUser() //function to determine whether beverage is alcoholic
    {
        std::cout << "Does this contain alcohol? (press 1 to confirm): ";
        std::string option{};
        std::string alcoholic_option;
        std::cin >> alcoholic_option;
        if(alcoholic_option == "1")
        {
            option = "Alcoholic"; //beverage alcoholic
        } else
        {
            option = "Non-alcoholic"; //beverage not alcoholic
        }
        return option;
    }
    int getCalorieFromUser() //function to take integer input from user for calories of beverage
    {
        std::cout << "enter calories: ";
        int calorie{};
        std::cin >> calorie;
        return calorie;
    }
    //---------Methods used to execute main abilities listed in Menu Program selections menu-----------------------------------
    //-------------Adding to Beverages menu----------------------------------------------------------------------------------------
    int AddBev()
    {
        std::cout << "Beverages: " << "\n"; //entering AddBev() function
        Beverage new_beverage; //creating object in Beverage class
        std::string name = new_beverage.getNameFromUser(); //taking in user inputs for the object in Beverage class
        int price = new_beverage.getPriceFromUser();
        std::string temp = new_beverage.getTempFromUser();
        std::string option = new_beverage.getOptionFromUser();
        int calorie = new_beverage.getCalorieFromUser();
        new_beverage.Item(); //call to virtual class

        //--------------Writing to Beverage Menu txt file--------------------------------------------------------------------------
        ofstream MenuFile("BeverageMenu.txt", ofstream::app); //writing to end of 'BeverageMenu.txt'
        MenuFile << std::left << std::setw(17) << name << std::left << std::setw(10) << price << std::left << std::setw(12) << temp
        << std::left << setw(20) << option << std::left << std::setw(20) << calorie << endl; //outputing user inputs in table format
        MenuFile.close(); //closing writing to 'BeverageMenu.txt'

        //-------------Reading from Beverage menu txt file-------------------------------------------------------------------------
        std::string menuText; //initialising string to use for reading in txt file line by line
        ifstream MenuReadFile("BeverageMenu.txt"); //reading in from txt file, this allows info to be stored in 'BeverageMenu.txt'

        //--------------Printing out new Beverages menu table----------------------------------------------------------------------
        static int counter = 0; //initialising counter for beverage item index
        std::cout << green << std::left << std::setw(17) << "Beverage Option" << std::left << std::setw(10) << "Price ($)" << std::left
        << std::setw(12) << "Temperature" << std::left << std::setw(20) << "Contents" << std::left << std::setw(20) << "Calories (kCal)" << endl;
        std::cout << white << "===============================================================================" << endl;
        while(getline (MenuReadFile, menuText))
            {
            std::cout << green <<  menuText << endl;
            std::cout << white << "-------------------------------------------------------------------------------" << endl;
            }
        MenuReadFile.close(); //closing reading from 'BeverageMent.txt'
        counter++; //beverage item index increments by 1 every time adding a new beverage
        return 0;
    }
//---------------Displaying Beverages Menu----------------------------------------------------------------------------------------
    int SeeBevMenu()
    {
        std::string menuText; //initialising string to use for reading txt file line by line
        ifstream MenuReadFile("BeverageMenu.txt"); //reading from 'BeverageMenu.txt'
        static int bev_count = 0; //initialsing counter for beverage item index
        //-----------Printing out Beverage menu table--------------------------------------------------------------------------------
        std::cout << backgrey << green << std::left << std::setw(17) << " Beverage Option" << std::left << std::setw(10) << "Price($)"
        << std::left << std::setw(12) << "Served Chilled" << std::left << std::setw(20) << "  Alcoholic" << std::left << std::setw(20)
        << "Calories(kCal)     " << endl; //printing out table headings and border
        std::cout << backgrey << white << "==============================================================================   " << endl;
        while(getline (MenuReadFile, menuText)) //reading in txt file line by line
            {
                bev_count++;
                std::cout << backgrey << green << bev_count << ": "; //displaying beverage item index
                std::cout << backgrey << green << menuText << "                " << endl; //colours are used to set word and background colours
                std::cout << backgrey << white << "-------------------------------------------------------------------------------  "
                << backwhite << endl;
            }
        MenuReadFile.close(); //closing reading from 'BeverageMenu.txt'
        return 0;
    }
//-------------Making order from Beverages Menu-------------------------------------------------------------------------------------
    int BevOrder()
    {
        fstream file("BeverageMenu.txt"); //reading and writing to txt file
        int item_number; //initialising integer refering to beverage item index and taking user input
        cout << "Enter item number: ";
        cin >> item_number;

        GotoLine(file, item_number); //reading in lines of 'BeverageMenu.txt' as variables
        string name, temp, option, calorie; //initialising variables
        int price;
        file >> name >> price >> temp >> option >> calorie;

        ofstream ReceiptBevFile("MenuReceipt.txt", ofstream::app); //creating and writing the name of the order to txt file
        ReceiptBevFile << name << endl;

        ofstream PriceBevFile("PriceReceipt.txt", ofstream::app); //creating and writing the price of the order to txt file
        PriceBevFile << price << endl;
        return 0;
    }
};
#endif